<?php
/*
Plugin Name: Skomat Members
Plugin URI: https://skomat.gr/
Description: Plugin για login, καρτέλα, αγώνες και διαχείριση αθλητών από supervisor.
Version: 3.0
Author: ALEX & Copilot
*/

if (!defined('ABSPATH')) exit;

// 🔐 Προσθήκη ρόλων
register_activation_hook(__FILE__, 'skomat_add_roles');
function skomat_add_roles() {
    add_role('supervisor', 'Supervisor', array(
        'read' => true,
        'edit_posts' => true,
        'manage_options' => true,
    ));
    add_role('athlete', 'Athlete', array(
        'read' => true
    ));
}

// 🔓 Shortcodes login
function login_supervisor_form() {
    ob_start(); ?>
    <h2>Είσοδος Διαχειριστή</h2>
    <form method="post">
        <input type="text" name="supervisor_username" placeholder="Όνομα χρήστη">
        <input type="password" name="supervisor_password" placeholder="Κωδικός πρόσβασης">
        <input type="submit" name="supervisor_login_submit" value="Είσοδος">
    </form>
    <?php return ob_get_clean();
}
add_shortcode('login_supervisor_form', 'login_supervisor_form');

function login_athlete_form() {
    ob_start(); ?>
    <h2>Είσοδος Αθλητή</h2>
    <form method="post">
        <input type="text" name="athlete_username" placeholder="Όνομα χρήστη">
        <input type="password" name="athlete_password" placeholder="Κωδικός πρόσβασης">
        <input type="submit" name="athlete_login_submit" value="Είσοδος">
    </form>
    <?php return ob_get_clean();
}
add_shortcode('login_athlete_form', 'login_athlete_form');

// 🔁 Login & Redirect
add_action('init', 'skomat_handle_login');
function skomat_handle_login() {
    if (isset($_POST['supervisor_login_submit'])) {
        $creds = array(
            'user_login' => sanitize_user($_POST['supervisor_username']),
            'user_password' => $_POST['supervisor_password'],
            'remember' => true
        );
        $user = wp_signon($creds, false);
        if (!is_wp_error($user) && in_array('supervisor', $user->roles)) {
            wp_redirect(home_url('/dashboard-supervisor'));
            exit;
        } else {
            echo '<p style="color:red;">Λάθος στοιχεία ή δικαιώματα διαχειριστή!</p>';
        }
    }

    if (isset($_POST['athlete_login_submit'])) {
        $creds = array(
            'user_login' => sanitize_user($_POST['athlete_username']),
            'user_password' => $_POST['athlete_password'],
            'remember' => true
        );
        $user = wp_signon($creds, false);
        if (!is_wp_error($user) && in_array('athlete', $user->roles)) {
            wp_redirect(home_url('/card-athlete'));
            exit;
        } else {
            echo '<p style="color:red;">Λάθος στοιχεία ή δικαιώματα αθλητή!</p>';
        }
    }
}
// 🎯 Καρτέλα Αθλητή
function show_athlete_card() {
    if (!is_user_logged_in()) return '<p>Πρέπει να συνδεθείτε για να δείτε την καρτέλα σας.</p>';

    $user = wp_get_current_user();
    if (!in_array('athlete', $user->roles)) return '<p>Η πρόσβαση επιτρέπεται μόνο σε αθλητές.</p>';

    $matches = get_user_meta($user->ID, 'athlete_matches', true);
    if (!is_array($matches)) $matches = [];

    usort($matches, fn($a, $b) => strtotime($a['date']) <=> strtotime($b['date']));

    ob_start();
    echo "<h2>Καρτέλα Αθλητή: " . esc_html($user->display_name) . "</h2>";
    echo "<ul><li><strong>Email:</strong> " . esc_html($user->user_email) . "</li>";
    echo "<li><strong>Συνολικοί Αγώνες:</strong> " . count($matches) . "</li></ul>";
    ?>
    <form method="get">
        <label>Από:</label> <input type="date" name="from">
        <label>Μέχρι:</label> <input type="date" name="to">
        <input type="submit" value="Φιλτράρισμα">
    </form>

    <button class="print-button" data-target="table-athlete-<?php echo $user->ID; ?>">🖨️ Εκτύπωση</button>
    <button class="pdf-button" data-target="table-athlete-<?php echo $user->ID; ?>">📄 PDF</button>
    <?php

    $from = isset($_GET['from']) ? strtotime($_GET['from']) : null;
    $to = isset($_GET['to']) ? strtotime($_GET['to']) : null;

    echo '<div id="table-athlete-' . $user->ID . '"><table border="1"><tr><th>#</th><th>Ημ/νία</th><th>Είδος</th><th>Τοποθεσία</th><th>Σχόλια</th></tr>';
    $i = 1;
    foreach ($matches as $match) {
        $d = strtotime($match['date']);
        if ($from && $d < $from) continue;
        if ($to && $d > $to) continue;
        echo "<tr><td>{$i}</td><td>" . date('d.m.Y', $d) . "</td><td>" . esc_html($match['name']) . "</td><td>" . esc_html($match['location']) . "</td><td>" . esc_html($match['notes']) . "</td></tr>";
        $i++;
    }
    echo '</table></div>';

    return ob_get_clean();
}
add_shortcode('athlete_card', 'show_athlete_card');


function show_supervisor_dashboard() {
    if (!is_user_logged_in()) return '<p>Πρέπει να συνδεθείτε.</p>';

    $user = wp_get_current_user();
    if (!in_array('supervisor', $user->roles)) return '<p>Μόνο supervisor έχει πρόσβαση.</p>';

    ob_start();
    echo '<h2>Supervisor Dashboard</h2>';
    echo '<p>
        <a href="' . home_url('/users-supervisor') . '"
           style="display:inline-block;padding:10px 16px;background:#0073aa;color:#fff;
                  text-decoration:none;border-radius:6px;font-weight:bold;">
           ➕ Διαχείριση Αθλητών
        </a><br>
        <span style="font-size:0.9em;color:#555;">Μεταβείτε στη σελίδα για να προσθέσετε ή να αφαιρέσετε αθλητές</span>
    </p>';

    // 👉 εδώ συνεχίζει το υπόλοιπο dashboard...

    // Διαγραφή αγώνα
    if (isset($_POST['delete_match']) && isset($_POST['delete_athlete_id']) && isset($_POST['delete_index'])) {
        $aid = intval($_POST['delete_athlete_id']);
        $index = intval($_POST['delete_index']);
        $matches = get_user_meta($aid, 'athlete_matches', true);
        if (is_array($matches) && isset($matches[$index])) {
            unset($matches[$index]);
            $matches = array_values($matches);
            update_user_meta($aid, 'athlete_matches', $matches);
            echo "<p style='color:red;'>Ο αγώνας διαγράφηκε.</p>";
        }
    }

    // Προσθήκη νέου αγώνα
    if (isset($_POST['submit_match']) && isset($_POST['athlete_id'])) {
        $aid = intval($_POST['athlete_id']);
        $type = $_POST['match_type_select'] === 'Άλλο' ? $_POST['match_type_custom'] : $_POST['match_type_select'];
        $loc = $_POST['match_location_select'] === 'Άλλο' ? $_POST['match_location_custom'] : $_POST['match_location_select'];
        $new = array(
            'date' => sanitize_text_field($_POST['match_date']),
            'name' => sanitize_text_field($type),
            'location' => sanitize_text_field($loc),
            'notes' => sanitize_text_field($_POST['match_notes']),
        );
        $matches = get_user_meta($aid, 'athlete_matches', true);
        if (!is_array($matches)) $matches = [];
        $matches[] = $new;
        update_user_meta($aid, 'athlete_matches', $matches);
        echo "<p style='color:green;'>Αγώνας προστέθηκε.</p>";
    }

    $athletes = get_users(array('role' => 'athlete'));
    ob_start();
    echo "<h2>Supervisor Dashboard</h2>";
    foreach ($athletes as $a) {
        echo "<hr><h3>" . esc_html($a->display_name) . " (" . esc_html($a->user_login) . ")</h3>";
        ?>
        <form method="post">
            <input type="hidden" name="athlete_id" value="<?php echo $a->ID; ?>">
            <label>Ημ/νία:</label><input type="date" name="match_date" required>
            <label>Είδος:</label>
            <select name="match_type_select">
                <option value="30+30">30+30</option><option value="10-8-6">10-8-6</option><option value="Άλλο">Άλλο</option>
            </select><input type="text" name="match_type_custom" placeholder="Άλλο είδος">
            <label>Τοποθεσία:</label>
            <select name="match_location_select">
                <option value="ΜΦΑΤ Χαϊδαρίου">ΜΦΑΤ Χαϊδαρίου</option><option value="Άλλο">Άλλο</option>
            </select><input type="text" name="match_location_custom" placeholder="Άλλη τοποθεσία">
            <label>Σχόλια:</label><input type="text" name="match_notes">
            <input type="submit" name="submit_match" value="Προσθήκη">
        </form>

        <button class="print-button" data-target="table-athlete-<?php echo $a->ID; ?>">🖨️ Εκτύπωση</button>
        <button class="pdf-button" data-target="table-athlete-<?php echo $a->ID; ?>">📄 PDF</button>
        <div id="table-athlete-<?php echo $a->ID; ?>">
        <table border="1"><tr><th>#</th><th>Ημ/νία</th><th>Είδος</th><th>Τοποθεσία</th><th>Σχόλια</th><th>Διαγραφή</th></tr>
        <?php
        $matches = get_user_meta($a->ID, 'athlete_matches', true);
        if (!is_array($matches)) $matches = [];
        usort($matches, fn($a, $b) => strtotime($a['date']) <=> strtotime($b['date']));
        foreach ($matches as $idx => $match) {
            $d = strtotime($match['date']);
            echo "<tr><td>" . ($idx+1) . "</td><td>" . date('d.m.Y', $d) . "</td><td>" . esc_html($match['name']) . "</td><td>" . esc_html($match['location']) . "</td><td>" . esc_html($match['notes']) . "</td>";
            echo "<td><form method='post' style='display:inline;'><input type='hidden' name='delete_athlete_id' value='{$a->ID}'><input type='hidden' name='delete_index' value='{$idx}'><input type='submit' name='delete_match' value='🗑️
// 👤 Διαχείριση Αθλητών στο Supervisor Dashboard
add_shortcode('supervisor_manage_users', function () {
    if (!is_user_logged_in()) return '<p>Πρέπει να συνδεθείτε.</p>';
    $user = wp_get_current_user();
    if (!in_array('supervisor', $user->roles)) return '<p>Δεν έχετε δικαίωμα πρόσβασης.</p>';

    // Προσθήκη νέου αθλητή
    if (isset($_POST['new_athlete_username'])) {
        $username = sanitize_user($_POST['new_athlete_username']);
        $email = sanitize_email($_POST['new_athlete_email']);
        $password = $_POST['new_athlete_password'];

        if (username_exists($username) || email_exists($email)) {
            echo "<p style='color:red;'>Ο χρήστης υπάρχει ήδη.</p>";
        } else {
            $id = wp_create_user($username, $password, $email);
            if (!is_wp_error($id)) {
                $u = get_user_by('id', $id);
                $u->set_role('athlete');
                echo "<p style='color:green;'>Ο αθλητής δημιουργήθηκε.</p>";
            } else {
                echo "<p style='color:red;'>Σφάλμα: " . $id->get_error_message() . "</p>";
            }
        }
    }

    // Διαγραφή αθλητή
    if (isset($_POST['delete_athlete_user'])) {
        $del_id = intval($_POST['delete_athlete_user']);
        $target = get_userdata($del_id);
        if ($target && in_array('athlete', $target->roles)) {
            wp_delete_user($del_id);
            echo "<p style='color:red;'>Ο αθλητής διαγράφηκε.</p>";
        } else {
            echo "<p style='color:red;'>Δεν μπορεί να διαγραφεί ο χρήστης.</p>";
        }
    }

    ob_start(); ?>
    <h2>Διαχείριση Αθλητών</h2>
    <form method="post">
        <label>Όνομα χρήστη:</label><input type="text" name="new_athlete_username" required>
        <label>Email:</label><input type="email" name="new_athlete_email" required>
        <label>Κωδικός:</label><input type="password" name="new_athlete_password" required>
        <input type="submit" value="➕ Προσθήκη Αθλητή">
    </form>
    <hr>
    <h3>Υπάρχοντες Αθλητές:</h3>
    <?php
    $athletes = get_users(['role' => 'athlete']);
    echo "<ul>";
    foreach ($athletes as $a) {
        echo "<li>" . esc_html($a->user_login) . " (" . esc_html($a->user_email) . ")
            <form method='post' style='display:inline;'>
                <input type='hidden' name='delete_athlete_user' value='{$a->ID}'>
                <input type='submit' value='🗑️ Διαγραφή'>
            </form></li>";
    }
    echo "</ul>";
    return ob_get_clean();
});
// 📦 JS για PDF & Print export
add_action('wp_footer', 'skomat_export_scripts');
function skomat_export_scripts() {
    ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // 🖨️ Εκτύπωση
            document.querySelectorAll(".print-button").forEach(btn => {
                btn.addEventListener("click", function () {
                    const targetId = btn.getAttribute("data-target");
                    const element = document.getElementById(targetId);
                    if (element) {
                        const win = window.open('', '', 'width=800,height=600');
                        win.document.write('<html><head><title>Εκτύπωση</title><style>table{border-collapse:collapse;width:100%}th,td{border:1px solid #999;padding:6px;text-align:left;font-family:Arial}</style></head><body>');
                        win.document.write(element.outerHTML);
                        win.document.write('</body></html>');
                        win.document.close();
                        win.print();
                    }
                });
            });

            // 📄 Export PDF
            document.querySelectorAll(".pdf-button").forEach(btn => {
                btn.addEventListener("click", function () {
                    const targetId = btn.getAttribute("data-target");
                    const element = document.getElementById(targetId);
                    if (element) {
                        html2pdf().set({
                            margin: 10,
                            filename: 'agones.pdf',
                            html2canvas: { scale: 2 },
                            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
                        }).from(element).save();
                    }
                });
            });
        });
    </script>
    <?php
}
            